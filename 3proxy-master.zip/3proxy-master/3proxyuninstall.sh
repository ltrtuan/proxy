/etc/init.d/3proxy stop
rm -rf /etc/3proxy
rm /etc/rc0.d/*proxy
rm /etc/rc1.d/*proxy
rm /etc/rc6.d/*proxy
rm /etc/rc2.d/*proxy
rm /etc/rc3.d/*proxy
rm /etc/rc4.d/*proxy
rm /etc/rc5.d/*proxy
rm /etc/init.d/3proxy